//
//  FacialView.swift
//  skinByAnaLaura
//
//  Created by ana presuel on 3/28/20.
//  Copyright © 2020 Phillip Presuel. All rights reserved.
//

import SwiftUI

struct SkinCareView: View {
    var body: some View {
        
        List {
        
            ZStack(alignment: .bottom) {
             
                Image("facial")
                .resizable()
                .aspectRatio(contentMode: .fit)
                
                Rectangle()
                .frame(height: 80)
                .opacity(0.25)
                .blur(radius: 10)
                
                HStack {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(facials[0])
                        .foregroundColor(.tan)
                        .font(.largeTitle)
                    }
                    .padding(.leading)
                    .padding(.bottom)
                    Spacer()
                }
            }
            .listRowInsets(EdgeInsets())
            
            ForEach(1 ..< facials.count) {
                Text(facials[$0])
                .font(.headline)
                .padding(.top)
                .padding(.bottom)
                Text(facialDescriptions[$0])
                .lineSpacing(10)
                .lineLimit(nil)
            }
            
        }
    }
}

struct SkinCareView_Previews: PreviewProvider {
    static var previews: some View {
        SkinCareView()
    }
}
