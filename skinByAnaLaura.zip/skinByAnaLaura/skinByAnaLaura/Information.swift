//
//  Information.swift
//  skinByAnaLaura
//
//  Created by ana presuel on 3/27/20.
//  Copyright © 2020 Phillip Presuel. All rights reserved.
//

// This file holds nearly all the text that is displayed in views, creating them all in constants would've been too messy and so forth.

import SwiftUI

let aboutMe: String = "Hi, I'm Ana Laura!\n I'm a believer in a more graceful approach to skincare. I want you to have healthy and beautiful skin. I want to help you build confidence from the inside-out. I offer anti-aging treatments and other services that leave you looking and feeling like you. I am constantly furthering my education and knowledge so make sure to checkout everything I have to offer.\n Thank you!"

let education: String = "I am a licensed esthetician that attended the Skin Academy at Paul Mitchell in Costa Mesa. Far before this I always had an interest in general health and skincare. As previously mentioned, I'm always looking to broaden my expertise, I will soon be adding eyelash services to my repertoire."

let facials: [String] = ["Skin Care" ,"Refreshing European Facial", "The Proper Pamper", "Ultimate Anti-Aging Experience", "The Acne Purifier", "The Rejuvenate", "Men's Facial Booster", "Vitamin-C Booster", "Stress Relieving Back Facial"]

let facialDescriptions: [String] = [
    "Fight effects of aging, combat acne, refresh your skin, or simply pamper yourself.",
    "Smooth, refresh, and soften your skin with a classic facial service. This deep cleansing, exfoliation, moisturizing, and fruit enzyme mask experience will leave you feeling great. Relieve the stress you've built up in your busy week and enjoy a face, neck, hand, and shoulder massage. Additional services, like extractions, can be discussed to further your experience.",
    "This package includes the classic European Facial, a glycolic skin renewal treatment, a parrafin hand treatment, an anti-aging eye complex, and a lip softening pamper. No pamper is complete without a proper face, neck, and shoulder massage.",
    "Revitalize your skin with a nourishing antioxidant vitamin mix. Fortify your skin and battle the natural effects of aging, sun damage, and product use. This moisturizing mixture helps to improve skin texture, tone, and promote heathier skin. This facial will leave you with the youthful brilliance it has always had.",
    "Do you experience pesky acne? Bad breakouts? Let's combat this with a comprehensive skin analysis, deep cleansing, intensive extractions, and with a finalizing mask. This experience helps to reduce oil secretion, bacteria, and impurities while detoxifying the skin. This facial is personalized to your skin type and skin needs.",
    "This efficient facial is perfect for a relaxing refresher. Toning, cleasing, exfoliation, and a moisturizing mask will have your skin feeling new. These products being peacefully worked into the skin will slow the aging process, hydrate, and protect your skin. This is a great tool for anyone that needs a quicker pamper.",
    "Let's alleviate the skin you tear up with constant shaving. Shaving bumps not only hurt, they don't look good. This treatment also helps to prevent future shaving bumps and irritations with a thorough approach. Finally, enjoy a relaxing massage of the neck and shoulders.",
    "Say goodbye to dull, sun-damaged, congested, and sensitive skin with the natural benefits of Vitamin C enzymes. Clear and brighten your naturally flawless complexion. Boost collagen production and heal skin irritation. Protect yourself from the harmful effects of sunlight and prevent signgs of aging.",
    "Let's relieve your back, neck, and shoulders that are prone to carry tension. Deep cleansing, exfoliation, extractions, and a good massage will help to relieve the stress on these important movers. A custom experience that is efficient in addressing your specific needs and relieving stress."
    ]

let faceWaxing: [String] = ["Waxing" ,"Eyebrows", "Full Face", "Lip/ Nose/ Cheeks", "Sideburns/ Hairline/ Neck"]

let faceWaxingDescription: [String] = [
"Quick and painless services to have you feeling luxoriously smooth.",
"Well done eyebrows are essential details in refining your look. Frame your face, compliment your eyes, and find your style. Find what shape and style goes most with your looks!",
"A full face wax is dependent on your needs. Most often the service includes, hairline, eyebrow design, sideburns, nose, cheeks, upper and lower lip, chin, and neck.",
"Gentle and efficient service to make sure you feel no pain. Catered to what you need and desire!",
"Do you have annoying baby hairs that always get in the way of your looks? We can cleanly remove these and make sure you feel clean as ever."
]

let bodyTitle: String = "Body"

let bodyWaxingDescription: String = "Gentle body waxing is done with the upmost precision to have you in no pain and on your way in no time. Feel confident in your skin with this reassuring smoothness and clean look."

let bodyWaxing: [String] = [
    "Underarms",
    "Full Arms",
    "Stomach Strip",
    "Half Arms"
]

extension Color {
    public static let blush: Color = Color(red: 0.87, green: 0.36, blue: 0.51)
    public static let tan: Color = Color(red: 0.82, green: 0.71, blue: 0.55)
}

