//
//  EducationView.swift
//  skinByAnaLaura
//
//  Created by ana presuel on 3/28/20.
//  Copyright © 2020 Phillip Presuel. All rights reserved.
//

import SwiftUI

struct EducationView: View {
    var body: some View {
        List {
        
            ZStack(alignment: .bottom) {
             
                Image("books")
                .resizable()
                .aspectRatio(contentMode: .fit)
                
                Rectangle()
                .frame(height: 80)
                .opacity(0.25)
                .blur(radius: 10)
                
                HStack {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Education")
                        .foregroundColor(.tan)
                        .font(.largeTitle)
                    }
                    .padding(.leading)
                    .padding(.bottom)
                    Spacer()
                }
            }
            .listRowInsets(EdgeInsets())
            
            Text(education)
            .padding(.top)
            .lineSpacing(10)
            .lineLimit(nil)
            
        }
    }
}

struct EducationView_Previews: PreviewProvider {
    static var previews: some View {
        EducationView()
    }
}
