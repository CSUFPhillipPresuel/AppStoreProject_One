//
//  ContentView.swift
//  skinByAnaLaura
//
//  Created by ana presuel on 3/27/20.
//  Copyright © 2020 Phillip Presuel. All rights reserved.
//


// This is my homepage.

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        NavigationView {
            ZStack {
                
                List {
                    
                    // Custom, horizontal scrolling row found on the RowUI file.
                    RowUI()
                    .frame(height: 320)
                    .padding(.top)
                    .padding(.bottom)
                    
                    Text("ABOUT ME")
                    .font(.title)
                    .foregroundColor(.blush)
                    
                    Image("aboutMe")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(.top)
                    .padding(.bottom)
            
                    Text(aboutMe)
                    .multilineTextAlignment(.center)
                    .lineSpacing(15)
                    .lineLimit(nil)
                    .font(.headline)
                    .padding(.top)
                    .padding(.bottom)
                    
                    Text("CONTACT ME")
                    .font(.title)
                    .foregroundColor(.blush)
                    Text("SKINBYANALAURA@GMAIL.COM")
                    .font(.headline)
                    .padding(.top)
                    .padding(.bottom)
                    
                }
                
            }
            
        .navigationBarTitle(Text("SKIN BY ANA LAURA"))
            
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
