//
//  RowUI.swift
//  skinByAnaLaura
//
//  Created by ana presuel on 3/27/20.
//  Copyright © 2020 Phillip Presuel. All rights reserved.
//

// File to hold my custom scrolling row.
import SwiftUI

struct RowUI: View {
    var body: some View {
        
        VStack(alignment: .leading) {
            
            Text("My Education and Services")
            .font(.title)
            .foregroundColor(.blush)
            
            
            ScrollView(.horizontal, showsIndicators: false) {
            
                HStack(alignment: .top) {
                    
                    NavigationLink(destination: EducationView()) {
                        EducationPreview()
                        .frame(width: 300)
                        .padding(.trailing, 30)
                    }
                    
                    NavigationLink(destination: SkinCareView()) {
                        SkinCarePreview()
                        .frame(width: 300)
                        .padding(.trailing, 30)
                    }
                    
                    NavigationLink(destination: WaxingView()) {
                        
                        WaxPreview()
                        .frame(width: 300)
                        .padding(.trailing, 30)
                        
                    }
                    
                    
                    
                }
                
            }
        }
        
    }
}

struct Skincare_Previews: PreviewProvider {
    static var previews: some View {
        RowUI()
    }
}
