//
//  WaxPreview.swift
//  skinByAnaLaura
//
//  Created by ana presuel on 3/27/20.
//  Copyright © 2020 Phillip Presuel. All rights reserved.
//

import SwiftUI

struct WaxPreview: View {
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 16.0){
            Image("candles")
            .resizable()
            .renderingMode(.original)
            .aspectRatio(contentMode: .fill)
            .frame(width:300, height:170)
            .cornerRadius(10)
            .shadow(radius: 10)
            
            VStack(alignment: .leading, spacing: 5.0) {
                Text(faceWaxing[0])
                .foregroundColor(.primary)
                .font(.headline)
                
                Text(faceWaxingDescription[0])
                .foregroundColor(.tan)
                .font(.subheadline)
                .multilineTextAlignment(.leading)
                .lineLimit(2)
                .frame(height: 40)
            }
            
        }
        
        
    }
    
}

struct WaxPreview_Previews: PreviewProvider {
    static var previews: some View {
        WaxPreview()
    }
}
