//
//  WaxingView.swift
//  skinByAnaLaura
//
//  Created by ana presuel on 3/28/20.
//  Copyright © 2020 Phillip Presuel. All rights reserved.
//

// All view files are the implementation of each different view when clicked on.

import SwiftUI

struct WaxingView: View {
    
    var body: some View {
        
        List {
        
            ZStack(alignment: .bottom) {
             
                Image("candles")
                .resizable()
                .aspectRatio(contentMode: .fit)
                
                Rectangle()
                .frame(height: 80)
                .opacity(0.25)
                .blur(radius: 10)
                HStack {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(faceWaxing[0])
                        .foregroundColor(.tan)
                        .font(.largeTitle)
                    }
                    .padding(.leading)
                    .padding(.bottom)
                    Spacer()
                }
            }
            .listRowInsets(EdgeInsets())
            
            ForEach(1 ..< faceWaxing.count) {
                Text(faceWaxing[$0])
                .font(.headline)
                .padding(.top)
                .padding(.bottom)
                Text(faceWaxingDescription[$0])
                .lineSpacing(10)
                .lineLimit(nil)
            }
            
            Text(bodyTitle)
            .font(.largeTitle)
            .padding(.top)
            .padding(.bottom)
            .foregroundColor(.tan)
            
            Text(bodyWaxingDescription)
            .lineSpacing(10)
            .lineLimit(nil)
            
            ForEach(1 ..< bodyWaxing.count) {
                Text(bodyWaxing[$0])
                .font(.headline)
                .padding(.top)
                .padding(.bottom)
            }
            
        }
            
    }
}

struct WaxingView_Previews: PreviewProvider {
    static var previews: some View {
        WaxingView()
    }
}
