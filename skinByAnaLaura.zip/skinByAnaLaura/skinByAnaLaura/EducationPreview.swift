//
//  EducationPreview.swift
//  skinByAnaLaura
//
//  Created by ana presuel on 3/28/20.
//  Copyright © 2020 Phillip Presuel. All rights reserved.
//

// All preview files are just the "buttons" in the row that take you to the view they correspond to.

import SwiftUI

struct EducationPreview: View {
    var body: some View {
        
        VStack(alignment: .leading, spacing: 16.0){
        Image("books")
        .resizable()
        .renderingMode(.original)
        .aspectRatio(contentMode: .fill)
        .frame(width:300, height:170)
        .cornerRadius(10)
        .shadow(radius: 10)
        
            VStack(alignment: .leading, spacing: 5.0) {
                Text("Education")
                .foregroundColor(.primary)
                .font(.headline)
                
                Text("Take a look at my formal education!")
                .foregroundColor(.tan)
                .font(.subheadline)
                .multilineTextAlignment(.leading)
                .frame(height: 40)
        }
    }
}

struct EducationPreview_Previews: PreviewProvider {
    static var previews: some View {
        EducationPreview()
    }
}
}
